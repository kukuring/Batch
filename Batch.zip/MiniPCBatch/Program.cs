﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace MiniPCBatch
{
    class Program
    {
        

        static void Main(string[] args)
        {
            string keyPath = "Software\\Policies\\Microsoft\\Windows\\CONTROL PANEL\\DESKTOP";
            System.Diagnostics.EventLog eventLog = new System.Diagnostics.EventLog();
            eventLog.Source = "MiniPCBatch";

            RegistryKey registryKey = Registry.CurrentUser.OpenSubKey(keyPath, true);

            string screenSaveTimeOut = registryKey.GetValue("ScreenSaveTimeOut").ToString();
            string screenSaverIsSecure = registryKey.GetValue("ScreenSaverIsSecure").ToString();
                        
            registryKey.SetValue("ScreenSaveTimeOut", "36000");
            registryKey.SetValue("ScreenSaverIsSecure", "0");
            
            screenSaveTimeOut = $"{screenSaveTimeOut} | {registryKey.GetValue("ScreenSaveTimeOut")}";
            screenSaverIsSecure = $"{screenSaverIsSecure} | {registryKey.GetValue("ScreenSaverIsSecure")}";

            eventLog.WriteEntry($"screenSaveTimeOut: {screenSaveTimeOut} , screenSaverIsSecure: {screenSaverIsSecure}", System.Diagnostics.EventLogEntryType.Information);

            registryKey.Close();

            if (args.Length > 0 && args[0] == "0")
            {
                POINT pt;
                GetCursorPos(out pt);
                SetCursorPos(pt.x + 1, pt.y + 1);
            }
        }



        [DllImport("user32.dll")]
        static extern int SetCursorPos(int x, int y);

        [DllImport("user32.dll")]
        static extern int GetCursorPos(out POINT pt);

        public struct POINT
        {
            public int x;
            public int y;
        }

    }
}
